"""
Viral Retention Slicer — Backend
FastAPI server that:
  1. Extracts transcripts from a target long-form/stream YouTube URL.
  2. Uses a pre-cached "style DNA" built from 20 reference Shorts transcripts.
  3. Sends both to Gemini for structured viral-segment extraction.
"""

import os
import re
import json
import logging
from typing import List, Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from dotenv import load_dotenv

from youtube_transcript_api import YouTubeTranscriptApi, TranscriptsDisabled, NoTranscriptFound
import yt_dlp

from google import genai
from google.genai import types

load_dotenv()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("viral-slicer")

APP_NAME = "Viral Retention Slicer"
MODEL_NAME = "gemini-3.5-flash"  # NOTE: verify this model id is live on your account;
                                  # swap to "gemini-2.0-flash" or similar if it 404s.

# ---------------------------------------------------------------------------
# Reference dataset (your 20 high-retention videos).
# We cache extracted transcripts on disk so we only hit yt-dlp/transcript API
# once per video, ever — this is the "credit-saving" pipeline.
# ---------------------------------------------------------------------------
REFERENCE_VIDEO_URLS = [
    "https://youtube.com/shorts/0gah1QCcbHw",
    "https://youtube.com/shorts/AIQbaqYbvIw",
    "https://youtube.com/shorts/ss14VCnqC78",
    "https://youtube.com/shorts/fxtQ-ozLgB4",
    "https://youtube.com/shorts/TBKhPcpKDWQ",
    "https://youtube.com/shorts/Y5Vef0yFqsk",
    "https://youtube.com/shorts/2M8xmtlGMAk",
    "https://youtube.com/shorts/Vl21j-UMALE",
    "https://youtube.com/shorts/dPwCp1acu0Q",
    "https://youtube.com/shorts/BdMIAoITKag",
    "https://youtube.com/shorts/SWeo4Oz1yoI",
    "https://youtube.com/shorts/0EgMi-UeFvI",
    "https://youtube.com/shorts/wKwp1munFz0",
    "https://youtube.com/shorts/B24vuzNB4DE",
    "https://youtube.com/shorts/a1TBXTJISsU",
    "https://youtube.com/shorts/y6HsR-owBiQ",
    "https://youtube.com/shorts/XHmiqribrm0",
    "https://youtube.com/shorts/kxTzawoHvb8",
    "https://youtube.com/shorts/zBf3_f3wgCI",
    "https://www.youtube.com/live/PLENvZIdR0I",
]

CACHE_DIR = os.path.join(os.path.dirname(__file__), ".cache")
os.makedirs(CACHE_DIR, exist_ok=True)
STYLE_CACHE_PATH = os.path.join(CACHE_DIR, "style_dna.json")

app = FastAPI(title=APP_NAME)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten this before real deployment
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------
class AnalyzeRequest(BaseModel):
    video_url: str = Field(..., description="Target long-form or stream YouTube URL")
    gemini_api_key: Optional[str] = Field(
        None, description="Optional per-request key if not set server-side"
    )


class ViralSegment(BaseModel):
    start_time: str
    end_time: str
    retention_reason: str
    hook_score: int = Field(..., ge=0, le=100)


class AnalyzeResponse(BaseModel):
    video_url: str
    segments: List[ViralSegment]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def extract_video_id(url: str) -> str:
    patterns = [
        r"(?:v=|/shorts/|/live/|youtu\.be/)([A-Za-z0-9_-]{11})",
    ]
    for pat in patterns:
        m = re.search(pat, url)
        if m:
            return m.group(1)
    raise ValueError(f"Could not extract a video ID from URL: {url}")


def fetch_transcript_text(url: str) -> str:
    """
    Try youtube-transcript-api first (fast, no download).
    Fall back to yt-dlp's subtitle extraction if that fails.
    """
    video_id = extract_video_id(url)

    try:
        transcript = YouTubeTranscriptApi.get_transcript(video_id)
        return " ".join(chunk["text"] for chunk in transcript)
    except (TranscriptsDisabled, NoTranscriptFound, Exception) as e:
        logger.warning(f"youtube-transcript-api failed for {video_id}: {e}. Falling back to yt-dlp.")

    ydl_opts = {
        "skip_download": True,
        "writesubtitles": True,
        "writeautomaticsub": True,
        "subtitleslangs": ["en"],
        "quiet": True,
        "outtmpl": os.path.join(CACHE_DIR, f"{video_id}.%(ext)s"),
    }
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
        for ext in ("en.vtt", "en.srt"):
            path = os.path.join(CACHE_DIR, f"{video_id}.{ext}")
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    raw = f.read()
                # strip VTT/SRT timing/formatting lines down to plain text
                lines = [
                    ln.strip() for ln in raw.splitlines()
                    if ln.strip() and "-->" not in ln and not ln.strip().isdigit()
                    and not ln.upper().startswith("WEBVTT")
                ]
                return " ".join(lines)
    except Exception as e:
        logger.error(f"yt-dlp subtitle fallback failed for {url}: {e}")

    return ""


def build_style_dna() -> str:
    """
    Build (or load cached) a condensed 'style DNA' string from the 20
    reference videos' transcripts. This is computed once and reused so we
    never re-spend API/video-processing credits on the reference set.
    """
    if os.path.exists(STYLE_CACHE_PATH):
        with open(STYLE_CACHE_PATH, "r", encoding="utf-8") as f:
            cached = json.load(f)
        return cached.get("style_dna", "")

    transcripts = []
    for url in REFERENCE_VIDEO_URLS:
        try:
            text = fetch_transcript_text(url)
            if text:
                transcripts.append(text)
        except Exception as e:
            logger.warning(f"Skipping reference video {url}: {e}")

    combined = "\n\n---\n\n".join(transcripts)

    with open(STYLE_CACHE_PATH, "w", encoding="utf-8") as f:
        json.dump({"style_dna": combined}, f)

    return combined


def get_client(api_key: Optional[str]) -> genai.Client:
    key = api_key or os.getenv("GEMINI_API_KEY")
    if not key:
        raise HTTPException(
            status_code=400,
            detail="No GEMINI_API_KEY found. Set it in backend/.env or pass gemini_api_key in the request.",
        )
    return genai.Client(api_key=key)


def call_gemini_for_segments(client: genai.Client, style_dna: str, target_transcript: str, video_url: str) -> List[dict]:
    system_prompt = f"""You are a viral-retention editing analyst. You have deep familiarity with this
creator's proven high-retention Shorts style, derived from 20 reference transcripts below. Study the
narrative formatting, hook patterns, and pacing loops in the reference material, then apply that lens
to a new long-form/stream transcript to find the strongest candidate viral clip segments.

=== REFERENCE STYLE DNA (20 high-retention videos, text-only) ===
{style_dna[:60000]}
=== END REFERENCE STYLE DNA ===

Respond ONLY with a JSON array (no markdown fences, no prose) of objects shaped exactly like:
[{{"start_time": "MM:SS", "end_time": "MM:SS", "retention_reason": "...", "hook_score": 0-100}}]
Return between 5 and 15 segments, ranked by hook_score descending.
"""

    user_prompt = f"""Target video URL: {video_url}

Target transcript (may be auto-generated, timestamps approximate):
{target_transcript[:120000]}
"""

    response = client.models.generate_content(
        model=MODEL_NAME,
        contents=[
            types.Content(role="user", parts=[types.Part(text=system_prompt + "\n\n" + user_prompt)])
        ],
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            temperature=0.4,
        ),
    )

    raw_text = response.text.strip()
    raw_text = re.sub(r"^```json|```$", "", raw_text, flags=re.MULTILINE).strip()

    try:
        data = json.loads(raw_text)
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse Gemini JSON output: {e}\nRaw: {raw_text[:500]}")
        raise HTTPException(status_code=502, detail="Model did not return valid JSON. Try again.")

    if not isinstance(data, list):
        raise HTTPException(status_code=502, detail="Model output was not a JSON array.")

    return data


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.get("/api/health")
def health():
    return {"status": "ok", "app": APP_NAME}


@app.post("/api/analyze", response_model=AnalyzeResponse)
def analyze(req: AnalyzeRequest):
    if not req.video_url.strip():
        raise HTTPException(status_code=400, detail="video_url is required.")

    client = get_client(req.gemini_api_key)

    style_dna = build_style_dna()
    if not style_dna:
        logger.warning("Style DNA is empty — reference transcripts may be unavailable.")

    target_transcript = fetch_transcript_text(req.video_url)
    if not target_transcript:
        raise HTTPException(
            status_code=422,
            detail="Could not extract a transcript for the target video (no captions available).",
        )

    segments_raw = call_gemini_for_segments(client, style_dna, target_transcript, req.video_url)

    try:
        segments = [ViralSegment(**s) for s in segments_raw]
    except Exception as e:
        logger.error(f"Segment validation failed: {e}")
        raise HTTPException(status_code=502, detail="Model output did not match expected segment schema.")

    return AnalyzeResponse(video_url=req.video_url, segments=segments)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
