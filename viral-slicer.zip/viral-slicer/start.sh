#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$SCRIPT_DIR/backend"
FRONTEND_DIR="$SCRIPT_DIR/frontend"
VENV_DIR="$BACKEND_DIR/.venv"

echo "== Viral Retention Slicer :: bootstrap =="

if [ ! -d "$VENV_DIR" ]; then
  echo "Creating virtualenv..."
  python3 -m venv "$VENV_DIR"
fi

source "$VENV_DIR/bin/activate"

echo "Installing backend dependencies..."
pip install --quiet --upgrade pip
pip install --quiet -r "$BACKEND_DIR/requirements.txt"

if [ ! -f "$BACKEND_DIR/.env" ]; then
  echo "GEMINI_API_KEY=your_key_here" > "$BACKEND_DIR/.env"
  echo "Created backend/.env — add your real Gemini key there."
fi

echo "Starting backend on http://localhost:8000 ..."
(cd "$BACKEND_DIR" && uvicorn main:app --host 0.0.0.0 --port 8000 --reload) &
BACKEND_PID=$!

trap 'kill $BACKEND_PID 2>/dev/null || true' EXIT

sleep 2

echo "Serving frontend on http://localhost:5500 ..."
cd "$FRONTEND_DIR"
python3 -m http.server 5500

wait $BACKEND_PID
