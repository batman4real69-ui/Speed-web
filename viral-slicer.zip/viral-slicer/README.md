# Viral Retention Slicer

## Setup
1. `chmod +x start.sh && ./start.sh` — creates a venv, installs backend deps, boots FastAPI (:8000) and serves the frontend (:5500).
2. Open http://localhost:5500 — you'll be prompted for your Gemini API key on first load (stored in sessionStorage only).
3. Paste a long-form/stream YouTube URL and hit "Slice It".

## Notes
- `backend/.env` — put your real `AQ.Ab8RN6Jv2oXorg0b3Lnq5M8ZZ2GJMIiu6To29MABv0cg7yWrTw` here (never commit it).
- The 20 reference video transcripts are pulled once via `youtube_transcript_api` (falling back to `yt-dlp`) and cached in `backend/.cache/style_dna.json` so you don't re-spend credits on every request.
- Model id is set to `gemini-3.5-flash` in `backend/main.py` — verify that's live on your account; swap to `gemini-2.0-flash` (or whatever's current) if it 404s.
- CORS is wide open (`*`) for local dev — lock this down before deploying anywhere public.
